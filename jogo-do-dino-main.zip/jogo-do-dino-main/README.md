# 👀 jogo-do-dino  

## 🎮️ Sobre
O projeto é recriar o famoso jogo do dinossauro sem internet. Realizado dentro do bootcamp HTML web Developer com o intuito de colocar em prática todo o conteúdo estudado durante o curso da DIO.

<img src=https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/dino.gif width="550">

## 👨‍💻️ Tecnogias utilizadas
O projeto foi desenvolvido utilizando as seguintes tecnologias:

💻️Javascript 💻️Visual Studio Code

## Feito com ❤️ por hellenm
